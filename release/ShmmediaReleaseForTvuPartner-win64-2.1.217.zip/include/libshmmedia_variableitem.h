#ifndef LIBSHMMEDIA_VARIABLEITEM_H
#define LIBSHMMEDIA_VARIABLEITEM_H
#include "libshm_media_variable_item.h"
#endif // LIBSHMMEDIA_VARIABLEITEM_H
