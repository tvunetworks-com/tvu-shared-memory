#ifndef LIBSHMMEDIA_DATA_PROTOCOL_H
#define LIBSHMMEDIA_DATA_PROTOCOL_H

#include "libshmmedia_tvulive_protocol.h"
#include "libshmmedia_encoding_protocol.h"
#include "libshmmedia_control_protocol.h"

#endif // LIBSHMMEDIA_DATA_PROTOCOL_H
