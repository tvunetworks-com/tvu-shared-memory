#ifndef LIBSHM_MEDIA_EXTENSION_PROTOCOL_H
#define LIBSHM_MEDIA_EXTENSION_PROTOCOL_H

#include <stdint.h>
#include "libshm_media_subtitle_private_protocol.h"

#ifdef __cplusplus
    extern "C" {
#endif

#if defined(TVU_WINDOWS)

#if defined (LIBSHMMEDIA_DLL_EXPORT)
#define _LIBSHMMEDIA_PROTO_DLL_ __declspec(dllexport)
#elif defined(LIBSHMMEDIA_DLL_IMPORT)
#define _LIBSHMMEDIA_PROTO_DLL_ __declspec(dllimport)
#else
#define _LIBSHMMEDIA_PROTO_DLL_
#endif

#else
#define _LIBSHMMEDIA_PROTO_DLL_ __attribute__((visibility("default")))
#endif

#define LIBSHM_MEDIA_TVULIVE_FOURCCTAG(a,b,c,d) ((a) | ((b) << 8) | ((c) << 16) | ((unsigned)(d) << 24))

typedef enum ELibShmMediaType
{
    LIBSHM_MEDIA_TYPE_INVALID = 0,
    LIBSHM_MEDIA_TYPE_TVU_UID = 1,
    LIBSHM_MEDIA_TYPE_TVU_INTERLACE_FLAG = 2,
    LIBSHM_MEDIA_TYPE_TVU_EXTEND_DATA = 3,
    LIBSHM_MEDIA_TYPE_TVU_EXTEND_DATA_V2 = 4,

    LIBSHM_MEDIA_TYPE_MAX_NUM = 1025,

    /* if frame protocol to use */
    LIBSHM_MEDIA_TYPE_TVULIVE_AUDIO = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'L', 'V', 'A'),
    LIBSHM_MEDIA_TYPE_TVULIVE_HEADER = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'L', 'V', 'H'),
    LIBSHM_MEDIA_TYPE_TVULIVE_VIDEO = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'L', 'V', 'V'),
    // user define the protocol at the tvulive data type
    LIBSHM_MEDIA_TYPE_TVULIVE_DATA = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'L', 'V', 'D'),
    LIBSHM_MEDIA_TYPE_ENCODING_DATA = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'E', 'N', 'C'),
    LIBSHM_MEDIA_TYPE_CONTROL_DATA = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'C', 'T', 'L'),
    LIBSHM_MEDIA_TYPE_MPEG_TS_DATA = LIBSHM_MEDIA_TVULIVE_FOURCCTAG('T', 'M', 'T', 'S'), /* used to transfer mpegts source stream */
    /* endif */

    LIBSHM_MEDIA_TYPE_TVU_OTHER_MEDIA_INFO = 0xffffffff,
    /* others is used for caller's self definition */
}libshm_media_type_t;

/**
 *  new extented data structure.
 *
 *  |---------------------------|
 *  |version(4Bytes)            |
 *  |0x 's', 'h', 'm', 'e'      |
 *  |total length(4Bytes)       |
 *  |counts(4Byte)              |
 *  |---------------------------|
 *  |type(4bytes)               |
 *  |len(4bytes)                |
 *  |data(bin)                  |
 *  |---------------------------|
 *  |type(4bytes)               |
 *  |len(4bytes)                |
 *  |data(bin)                  |
 *  |---------------------------|
 *  |                           |
 *  |           ...             |
 *  |                           |
 *  |---------------------------|
 *
**/

enum ELibShmMediaExtendDataTypeV2
{
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_UNKNOWN = 0,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_UID = 1,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_CC608_CDP = 2,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_CAPTION_TEXT = 3,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_PRODUCER_STREAM_INFO = 4,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_RECEIVER_INFO = 5,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SCTE104_DATA = 6,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_TIMECODEINDEX = 7,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_STARTIMECODE = 8,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_HDR_METADATA = 9,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SCTE35_DATA = 10,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_TIMECODE_WITH_FPS_INDEX = 11,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_PIC_STRUCT = 12,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SOURCE_TIMESTAMP = 13,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_TIMECODE = 14,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_METADATA_PTS = 15,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SOURCE_TIMEBASE = 16,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SMPTE_AFD_METADATA = 17,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SOURCE_ACTION_TIMESTAMP = 18,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_VANC_SMPTE2038 = 19,
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_GOP_POC_V1 = 20,

    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_PROTOCOL_EXTENTION_RESERVER = 0x10000, /* reserver protocol of subtitle for future. */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_PRIVATE_PROTOCOL_EXTENTION_STRUCTURE =LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_PROTOCOL_EXTENTION_RESERVER, /* reserver protocol of subtitle for future. */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_DVB_TELETEXT = 0x10001, /* dvb teletext */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_DVB_SUBTITLE = 0x10002, /* dvb subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_DVD_SUBTITLE = 0x10003, /* dvd subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_WEBVTT = 0x10004, /* webvtt subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_SRT = 0x10005, /* SubRip subtitle with embedded timing */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_SUBRIP = 0x10006, /* SubRip subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_RAW_TEXT = 0x10007, /* raw UTF-8 text */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_TTML = 0x10008, /* Timed Text Markup Language */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_VPLAYER = 0x10009, /* VPlayer subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_EIA608 = 0x1000a, /* EIA-608 closed captions */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_SSA = 0x1000b, /* SSA (SubStation Alpha) subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_ASS = 0x1000c, /* ASS (Advanced SSA) subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_STL = 0x1000d, /* Spruce subtitle format */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_SUBVIEW = 0x1000e, /* SubViewer subtitle */
    LIBSHMMEDIA_EXTEND_DATA_TYPE_V2_SUBTITLE_SUBVIEWV1 = 0x1000f, /* SubViewer V1 subtitle */
};

typedef struct _LibShmMediaExtendedEntryData
{
    uint32_t    u_len;
    uint32_t    u_type;
    const uint8_t *p_data;
}libshmmedia_extended_entry_data_t;


#define TVU_SHM_USER_DATA_SIZE  1024
#define TVU_SHM_PRODUCER_STREAM_INFO_BUFFER_LENGTH 128

typedef struct _ShmExtendDataStruct
{
    const uint8_t*      p_uuid_data;
    int                 i_uuid_length;
    const uint8_t*      p_cc608_cdp_data;
    int                 i_cc608_cdp_length;
    const uint8_t*      p_caption_text;
    int                 i_caption_text_length;
    const uint8_t*      p_producer_stream_info;
    int                 i_producer_stream_info_length;
    const uint8_t*      p_receiver_info;
    int                 i_receiver_info_length;
    const uint8_t*      p_scte104_data;
    int                 i_scte104_data_len;
    const uint8_t*      p_scte35_data;
    int                 i_scte35_data_len;
    /* old timecode, deprecated --> */
    const uint8_t*      p_timecode_index;
    int                 i_timecode_index_length;
    const uint8_t*      p_start_timecode;
    int                 i_start_timecode_length;
    /* <-- old timecode, deprecated */
    const uint8_t*      p_hdr_metadata;
    int                 i_hdr_metadata;
    /* new timecode, which has fps/index --> */
    const uint8_t*      p_timecode_fps_index;
    int                 i_timecode_fps_index;
    /* <-- new timecode, which has fps/index */
    const uint8_t*      p_pic_struct;
    int                 i_pic_struct;
    const uint8_t*      p_source_timestamp;
    int                 i_source_timestamp;
    /* timecode for muxer, standard hh::mm::ss.frame --> */
    const uint8_t*      p_timecode;
    int                 i_timecode;
    /* <-- timecode for muxer, standard hh::mm::ss.frame */

    /* <-- metadata pts, 64bit timestamp */
    const uint8_t*      p_metaDataPts;// little endian uint64 data.
    int                 i_metaDataPts;
    /* <-- metadata pts, 64bit timestamp */
    const uint8_t*      p_source_timebase;
    int                 i_source_timebase;
    /* <-- smpte afd metadata */
    const uint8_t*      p_smpte_afd_data;
    int                 i_smpte_afd_data;

    /* <-- source action timestamp was used to record the input source original action timestamp, milliseconds, 8bytes. */
    const uint8_t*      p_source_action_timestamp;
    int                 i_source_action_timestamp;
    /* --> source action timestamp */

    /* <-- vanc_smpte2038 was used to store vanc smpte 2038 meta data */
    const uint8_t*      p_vanc_smpte2038;
    int                 i_vanc_smpte2038;
    /* --> vanc_smpte2038 */

    /* <-- used to express gop poc information, uint32 little endian. */
    const uint8_t*      p_gop_poc;
    int                 i_gop_poc;
    /* --> used to express gop poc information */

    uint32_t            u_subtitle_type;
    const uint8_t*      p_subtitle;
    int                 i_subtitle;
}Lib_shm_extend_data_t, libshmmedia_extend_data_info_t;

/**
 *  Functionality:
 *      parsing the pShmUserData data out, assign the value to pExtendData.
 *
 *  Parameters:
 *      @pShmUserData[IN]   :   external buffer point.
 *      @dataSize[IN]       :   input buffer real size.
 *      @pExtendData[OUT]   :   destination external data structure.
 *  Return:
 *      void.
 *
 *  ===============================================
 *       v1 user data structure
 *  ===============================================
 *
 *  |---------------------------|
 *  |DataFlag(4Bytes)           |
 *  |---------------------------|
 *  |len(4bytes)                |
 *  |data(bin)                  |
 *  |---------------------------|
 *  |len(4bytes)                |
 *  |data(bin)                  |
 *  |---------------------------|
 *  |           ...             |
 *  |---------------------------|
 *
**/

//old deprecated API for read v1 user data,use libShmReadExtendDataV2 to instead
//_LIBSHMMEDIA_PROTO_DLL_
//void libShmReadExtendData(Lib_shm_extend_data_t* pExtendData,const uint8_t* pShmUserData,int dataSize);


typedef void * libshmmedia_extended_data_context_t;

/************************************************************************/
/* a wrap for parser user data by userDataType                          */
/*      return 0 for success,<0 for error                               */
/************************************************************************/
/**
 *  Description:
 *      used to read out extended data, the data point was not at @pShmUserData but at the internal buffer of @v2DataCtx
**/
_LIBSHMMEDIA_PROTO_DLL_
int LibShmMediaReadExtendData(libshmmedia_extend_data_info_t* pExtendData, const uint8_t* pShmUserData, int dataSize, int userDataType, libshmmedia_extended_data_context_t v2DataCtx);

/**
 *  Description:
 *      used to read out extended data, the data point was not at @pShmUserData but at the internal buffer of @v2DataCtx
**/
_LIBSHMMEDIA_PROTO_DLL_
int libShmReadExtendDataV2(libshmmedia_extend_data_info_t* pExtendData, const uint8_t* pShmUserData, int dataSize, int userDataType, libshmmedia_extended_data_context_t v2DataCtx);

/**
 *  Description:
 *      used to read out extended data, the data point was at @pShmUserData
 *  Return:
 *      0 - success, <0 - failed
**/
_LIBSHMMEDIA_PROTO_DLL_
int LibShmMeidaParseExtendData(libshmmedia_extend_data_info_t* pExtendData, const uint8_t* pShmUserData, int dataSize, int userDataType);


/**
 *  Functionality:
 *      used to estimate the buffer size for extend data.
 *  Parameters:
 *      @pExtendData[IN]    :   src external data information structure.
 *  Return:
 *      > 0     :   buffer size.
 *      = 0     :   no buffer needed.
 *      < 0     :   impossible
**/
_LIBSHMMEDIA_PROTO_DLL_
int LibShmMediaEstimateExtendDataSize(/*IN*/const libshmmedia_extend_data_info_t* pExtendData);

/**
 *  Functionality:
 *      a func to create V2 user data buffer API
 *  Parameters:
 *      @dataBuffer[OUT]    :   destination buffer
 *      @buffersize[IN]     :   destination buffer size
 *      @pExtendData[IN]    :   src external data information structure.
 *  Return:
 *      >= 0    :   return the real writing size to the buffer.
 *      < 0     :   failed to write.
**/
_LIBSHMMEDIA_PROTO_DLL_
int libShmWriteExtendData(/*OUT*/uint8_t dataBuffer[], /*IN*/int bufferSize, /*IN*/const libshmmedia_extend_data_info_t* pExtendData);
_LIBSHMMEDIA_PROTO_DLL_
int LibShmMediaWriteExtendData(/*OUT*/uint8_t dataBuffer[], /*IN*/int bufferSize, /*IN*/const libshmmedia_extend_data_info_t* pExtendData);

_LIBSHMMEDIA_PROTO_DLL_
libshmmedia_extended_data_context_t
LibshmMediaExtDataCreateHandle();

_LIBSHMMEDIA_PROTO_DLL_
void LibshmMediaExtDataResetEntry(libshmmedia_extended_data_context_t h);

/**
 *  Return:
 *      the real writing buffer size
**/
_LIBSHMMEDIA_PROTO_DLL_
unsigned int LibshmMediaExtDataGetEntryBuffSize(libshmmedia_extended_data_context_t h);

/**
 *  Return:
 *      >=0, the real writing bytes to dst buffer.
 *      <0, adding entry failed.
**/
_LIBSHMMEDIA_PROTO_DLL_
int LibshmMediaExtDataAddOneEntry(libshmmedia_extended_data_context_t h
    , libshmmedia_extended_entry_data_t *pEntryData
    , uint8_t *pDstBuf, uint32_t iDstBufSize
);

/**
 *  Return:
 *      >=0 : entry couts to parse out.
 *      <0  : failed to parse.
**/
_LIBSHMMEDIA_PROTO_DLL_
int LibshmMediaExtDataParseBuff(libshmmedia_extended_data_context_t h, const uint8_t *pbuf, uint32_t ibuflen);

/**
 *  Return:
 *      current entry couts.
**/
_LIBSHMMEDIA_PROTO_DLL_
unsigned int LibshmMediaExtDataGetEntryCounts(libshmmedia_extended_data_context_t h);

/**
 *  Return:
 *      0 : get entry data successfully.
 *      <0  : failed to get.
**/
_LIBSHMMEDIA_PROTO_DLL_
int LibshmMediaExtDataGetOneEntry(libshmmedia_extended_data_context_t h
    , int entryIndex
    , libshmmedia_extended_entry_data_t *pEntry);


_LIBSHMMEDIA_PROTO_DLL_
void LibshmMediaExtDataDestroyHandle(libshmmedia_extended_data_context_t *ph);

#ifdef __cplusplus
}
#endif

#endif // LIBSHM_MEDIA_EXTENSION_PROTOCOL_H
