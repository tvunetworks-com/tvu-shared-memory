#ifndef LIBSHM_MEDIA_PROTOCOL_LOG_H
#define LIBSHM_MEDIA_PROTOCOL_LOG_H

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif // LIBSHM_MEDIA_PROTOCOL_LOG_H
