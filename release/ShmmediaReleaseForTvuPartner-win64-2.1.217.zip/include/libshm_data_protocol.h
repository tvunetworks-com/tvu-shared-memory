/******************************************************************************
 *  File:
 *    libshm_data_protocol.h
 *  Description:
 *    used to declare data protocol apis here
 * Author:
 *    Lotus/TVU initialize on June 24th 2021
******************************************************************************/

#ifndef _LIBSHM_MEDIA_DATA_PROTOCOL_H
#define _LIBSHM_MEDIA_DATA_PROTOCOL_H   1

#include "libshmmedia_data_protocol.h"

#endif
